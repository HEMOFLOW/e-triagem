<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}
include_once 'config/database.php';
$pdo = getConnection();
$id = $_SESSION['usuario_id'];
$stmt = $pdo->prepare('SELECT * FROM usuarios WHERE id = ?');
$stmt->execute([$id]);
$usuario = $stmt->fetch();
if (!$usuario) { echo 'Usuário não encontrado.'; exit; }
$mensagem = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'] ?? $usuario['nome'];
    $telefone = $_POST['telefone'] ?? $usuario['telefone'];
    $email = $_POST['email'] ?? $usuario['email'];
    $sql = 'UPDATE usuarios SET nome = ?, telefone = ?, email = ? WHERE id = ?';
    $stmt = $pdo->prepare($sql);
    if ($stmt->execute([$nome, $telefone, $email, $id])) {
        $mensagem = '<div style="background:#d4edda;border:1px solid #155724;color:#155724;padding:10px;margin-bottom:15px;font-weight:bold;">Perfil atualizado com sucesso!</div>';
        $usuario['nome'] = $nome;
        $usuario['telefone'] = $telefone;
        $usuario['email'] = $email;
    } else {
        $mensagem = '<div style="background:#f8d7da;border:1px solid #721c24;color:#721c24;padding:10px;margin-bottom:15px;font-weight:bold;">Erro ao atualizar perfil!</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Perfil do Usuário</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <h2>Meu Perfil</h2>
        <?php echo $mensagem; ?>
        <form method="post">
            <label for="nome">Nome:</label>
            <input type="text" name="nome" id="nome" value="<?php echo htmlspecialchars($usuario['nome']); ?>" required>
            <br><br>
            <label for="telefone">Telefone:</label>
            <input type="text" name="telefone" id="telefone" value="<?php echo htmlspecialchars($usuario['telefone']); ?>" required>
            <br><br>
            <label for="email">E-mail:</label>
            <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($usuario['email']); ?>">
            <br><br>
            <button type="submit" class="btn btn-primary">Salvar Alterações</button>
            <a href="dashboard.php" class="btn btn-secondary">Voltar</a>
        </form>
    </div>
</body>
</html>
