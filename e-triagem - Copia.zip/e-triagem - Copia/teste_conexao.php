<?php
require_once 'config/database.php';

try {
    $pdo = getConnection();
    echo '<div style="background:#d4edda;border:1px solid #155724;color:#155724;padding:10px;margin:20px;font-weight:bold;">✅ Conexão com o banco de dados estabelecida com sucesso!</div>';
} catch (PDOException $e) {
    echo '<div style="background:#f8d7da;border:1px solid #721c24;color:#721c24;padding:10px;margin:20px;font-weight:bold;">❌ Erro ao conectar ao banco de dados: ' . $e->getMessage() . '</div>';
}
?>
