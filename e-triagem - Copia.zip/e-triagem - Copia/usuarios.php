<?php
session_start();

// Verifica se está logado e se é administrador
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

include_once 'config/database.php';
$pdo = getConnection();

// Filtro de busca
$filtro = $_GET['filtro'] ?? '';
$usuarios = [];

if ($filtro) {
    $sql = "SELECT * FROM usuarios WHERE nome LIKE ? OR cpf LIKE ? ORDER BY nome ASC";
    $stmt = $pdo->prepare($sql);
    $busca = "%$filtro%";
    $stmt->execute([$busca, $busca]);
    $usuarios = $stmt->fetchAll();
} else {
    $stmt = $pdo->query("SELECT * FROM usuarios ORDER BY nome ASC");
    $usuarios = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Lista de Usuários</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .table { width: 100%; border-collapse: collapse; margin-top: 24px; }
        .table th, .table td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        .table th { background: #f8f9fa; }
        .btn { padding: 6px 12px; border-radius: 4px; border: none; cursor: pointer; }
        .btn-edit { background: #155724; color: #fff; }
        .btn-view { background: #007bff; color: #fff; }
        .status-apto { background: #d4edda; color: #155724; padding: 2px 8px; border-radius: 3px; }
        .status-inapto { background: #f8d7da; color: #721c24; padding: 2px 8px; border-radius: 3px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Usuários Cadastrados</h2>
        <form method="get" style="margin-bottom:16px;">
            <input type="text" name="filtro" placeholder="Buscar por nome ou CPF" value="<?php echo htmlspecialchars($filtro); ?>" style="padding:8px;width:250px;">
            <button type="submit" class="btn btn-view">Buscar</button>
        </form>
        <table class="table">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>CPF</th>
                    <th>Status Doador</th>
                    <th>Última Doação</th>
                    <th>Última Resposta Questionário</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarios as $usuario): ?>
                    <?php
                    // Buscar status do doador
                    $stmt = $pdo->prepare("SELECT * FROM doadores WHERE usuario_id = ?");
                    $stmt->execute([$usuario['id']]);
                    $doador = $stmt->fetch();
                    // Buscar última doação
                    $ultima_doacao = $doador && $doador['ultima_doacao'] ? date('d/m/Y', strtotime($doador['ultima_doacao'])) : '-';
                    // Status doador
                    $status = $doador ? ($doador['apto_para_doacao'] ? 'Apto' : 'Inapto') : 'Não cadastrado';
                    $statusClass = $doador ? ($doador['apto_para_doacao'] ? 'status-apto' : 'status-inapto') : '';
                    // Buscar última resposta do questionário
                    $stmt = $pdo->prepare("SELECT aprovado, data_preenchimento FROM questionarios WHERE usuario_id = ? ORDER BY data_preenchimento DESC LIMIT 1");
                    $stmt->execute([$usuario['id']]);
                    $quest = $stmt->fetch();
                    $respQuest = $quest ? ($quest['aprovado'] ? 'Aprovado' : 'Reprovado') . ' em ' . date('d/m/Y', strtotime($quest['data_preenchimento'])) : '-';
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($usuario['nome']); ?></td>
                        <td><?php echo htmlspecialchars($usuario['cpf']); ?></td>
                        <td><span class="<?php echo $statusClass; ?>"><?php echo $status; ?></span></td>
                        <td><?php echo $ultima_doacao; ?></td>
                        <td><?php echo $respQuest; ?></td>
                        <td>
                            <a href="visualizar_usuario.php?id=<?php echo $usuario['id']; ?>" class="btn btn-view">Visualizar</a>
                            <?php if ($doador): ?>
                                <a href="editar_doador.php?id=<?php echo $doador['id']; ?>" class="btn btn-edit">Editar Status</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
