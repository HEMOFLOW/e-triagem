<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}
include_once 'config/database.php';
$pdo = getConnection();
$id = $_GET['id'] ?? '';
if (!$id) { echo 'Doador não encontrado.'; exit; }
$stmt = $pdo->prepare('SELECT * FROM doadores WHERE id = ?');
$stmt->execute([$id]);
$doador = $stmt->fetch();
if (!$doador) { echo 'Doador não encontrado.'; exit; }
$mensagem = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['apto_para_doacao'] ?? '';
    $sql = 'UPDATE doadores SET apto_para_doacao = ? WHERE id = ?';
    $stmt = $pdo->prepare($sql);
    if ($stmt->execute([$status, $id])) {
        $mensagem = '<div style="background:#d4edda;border:1px solid #155724;color:#155724;padding:10px;margin-bottom:15px;font-weight:bold;">Status atualizado com sucesso!</div>';
        $doador['apto_para_doacao'] = $status;
    } else {
        $mensagem = '<div style="background:#f8d7da;border:1px solid #721c24;color:#721c24;padding:10px;margin-bottom:15px;font-weight:bold;">Erro ao atualizar status!</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Status do Doador</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <h2>Editar Status do Doador</h2>
        <?php echo $mensagem; ?>
        <form method="post">
            <label for="apto">Status do Doador:</label>
            <select name="apto_para_doacao" id="apto">
                <option value="1" <?php if ($doador['apto_para_doacao']) echo 'selected'; ?>>Apto</option>
                <option value="0" <?php if (!$doador['apto_para_doacao']) echo 'selected'; ?>>Inapto</option>
            </select>
            <br><br>
            <button type="submit" class="btn btn-primary">Salvar</button>
            <a href="visualizar_usuario.php?id=<?php echo $doador['usuario_id']; ?>" class="btn btn-secondary">Voltar</a>
        </form>
    </div>
</body>
</html>
