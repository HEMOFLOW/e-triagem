<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}
include_once 'config/database.php';
$pdo = getConnection();
$id = $_GET['id'] ?? '';
if (!$id) { echo 'Usuário não encontrado.'; exit; }
$stmt = $pdo->prepare('SELECT * FROM usuarios WHERE id = ?');
$stmt->execute([$id]);
$usuario = $stmt->fetch();
if (!$usuario) { echo 'Usuário não encontrado.'; exit; }
$stmt = $pdo->prepare('SELECT * FROM doadores WHERE usuario_id = ?');
$stmt->execute([$id]);
$doador = $stmt->fetch();
$stmt = $pdo->prepare('SELECT * FROM questionarios WHERE usuario_id = ? ORDER BY data_preenchimento DESC LIMIT 1');
$stmt->execute([$id]);
$quest = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Visualizar Usuário</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <h2>Dados do Usuário</h2>
        <p><strong>Nome:</strong> <?php echo htmlspecialchars($usuario['nome']); ?></p>
        <p><strong>CPF:</strong> <?php echo htmlspecialchars($usuario['cpf']); ?></p>
        <p><strong>Telefone:</strong> <?php echo htmlspecialchars($usuario['telefone']); ?></p>
        <p><strong>E-mail:</strong> <?php echo htmlspecialchars($usuario['email'] ?: 'Não informado'); ?></p>
        <p><strong>Data de Nascimento:</strong> <?php echo date('d/m/Y', strtotime($usuario['data_nascimento'])); ?></p>
        <hr>
        <h3>Status de Doador</h3>
        <?php if ($doador): ?>
            <p><strong>Tipo Sanguíneo:</strong> <?php echo htmlspecialchars($doador['tipo_sanguineo'] . $doador['rh']); ?></p>
            <p><strong>Peso:</strong> <?php echo htmlspecialchars($doador['peso']); ?> kg</p>
            <p><strong>Altura:</strong> <?php echo htmlspecialchars($doador['altura']); ?> m</p>
            <p><strong>Status:</strong> <?php echo $doador['apto_para_doacao'] ? 'Apto' : 'Inapto'; ?></p>
            <p><strong>Última Doação:</strong> <?php echo $doador['ultima_doacao'] ? date('d/m/Y', strtotime($doador['ultima_doacao'])) : '-'; ?></p>
            <p><strong>Próxima Doação:</strong> <?php echo $doador['proxima_doacao'] ? date('d/m/Y', strtotime($doador['proxima_doacao'])) : '-'; ?></p>
            <a href="editar_doador.php?id=<?php echo $doador['id']; ?>" class="btn btn-primary">Editar Status do Doador</a>
        <?php else: ?>
            <p>Usuário não cadastrado como doador.</p>
        <?php endif; ?>
        <hr>
        <h3>Última Resposta do Questionário</h3>
        <?php if ($quest): ?>
            <p><strong>Status:</strong> <?php echo $quest['aprovado'] ? 'Aprovado' : 'Reprovado'; ?></p>
            <p><strong>Data:</strong> <?php echo date('d/m/Y H:i', strtotime($quest['data_preenchimento'])); ?></p>
        <?php else: ?>
            <p>Usuário ainda não respondeu o questionário.</p>
        <?php endif; ?>
        <hr>
        <a href="usuarios.php" class="btn btn-secondary">Voltar à lista</a>
    </div>
</body>
</html>
